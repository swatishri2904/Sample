const express = require('express');
const teacher = require('../model/teacher');
const router = express.Router();

router.get("/teacher/:username", async (req, res) => {
    try {
      const username = req.params.username;
      const result = await teacher.findOne({ where: { username } });
  
      if (result) {
        res.json(result);
      } else {
        res.status(404).json({ message: "Teacher not found" });
      }
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

router.post("/teacher",(req,res) =>  {
    const {username, password} = req.body
    const newTeacher = {username:username, password:password}
    teacher.create(newTeacher);
    res.json(newTeacher);


});



module.exports=router;