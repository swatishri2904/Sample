const sequelize = require('../connection/sequelize') ;
const Sequelize = require("sequelize");
// Define a teacher model
const teacher = sequelize.define('teacher', {
    username: {
        type: Sequelize.STRING,
        primaryKey: true
    },
    password: Sequelize.STRING,
    
    
    }, {

    timestamps: false, }
    
    );

teacher.sync()
    .then(() => {
        console.log('teacher table Synced');
    })
    .catch(error => {
        console.log('Error creating teacher table:', error);
    });


module.exports = teacher;