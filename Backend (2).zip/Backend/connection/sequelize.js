const Sequelize = require("sequelize");

const sequelize = new Sequelize('SchoolDB', 'admin', 'adminadmin', {
    host: 'database-1.c5tslsbvypfs.ap-south-1.rds.amazonaws.com',
    dialect: 'mysql',
});

module.exports = sequelize;