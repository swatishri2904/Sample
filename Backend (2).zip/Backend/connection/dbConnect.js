const mysql = require('mysql2')


const db = mysql.createConnection({
    host:'database-1.c5tslsbvypfs.ap-south-1.rds.amazonaws.com',
    user:'admin',
    password:'adminadmin',
    database:'SchoolDB',
    port:3306

});

//check database connection

db.connect(err=>{
    if (err){console.log('dberr');}
    console.log('database connected ...');
})


module.exports = db;