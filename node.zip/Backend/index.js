const express = require('express');
const bodyparser = require('body-parser');
const cors = require('cors');
const db = require('./connection/dbConnect')
const app = express();

app.use(cors());
app.use(bodyparser.json());



app.use("", require("./Controllers/teacher"));
app.use("", require("./Controllers/student"));

app.listen(3000,()=>{
    console.log('server running..');
})