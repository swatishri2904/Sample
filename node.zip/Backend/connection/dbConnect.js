const mysql = require('mysql2')


const db = mysql.createConnection({
    host:'mydbserver2.mysql.database.azure.com',
    user:'admin123',
    password:'nagarro@123',
    database:'schooldb',
    port:3306

});

//check database connection

db.connect(err=>{
    if (err){console.log('dberr');}
    console.log('database connected ...');
})


module.exports = db;