const Sequelize = require("sequelize");

const sequelize = new Sequelize('schooldb', 'admin123', 'nagarro@123', {
    host: 'mydbserver2.mysql.database.azure.com',
    dialect: 'mysql',
});

module.exports = sequelize;