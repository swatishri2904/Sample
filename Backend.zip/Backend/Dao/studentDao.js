const Student = require('../model/student')



function getAllStudents(callback) {
    Student.findAll()
      .then(students => {
        console.log('All students:', students);
        callback(null, students);
      })
      .catch(error => {
        console.log('Error retrieving students:', error);
        callback(error, null);
      });
  }
  
  function getStudentByRollNumber(rollNumber, callback) {
    Student.findOne({ where: { rollNumber } })
      .then(student => {
        if (!student) {
          callback(null, null);
        } else {
          console.log('Student:', student);
          callback(null, student);
        }
      })
      .catch(error => {
        console.log('Error retrieving student:', error);
        callback(error, null);
      });
  }
  
  function addStudent(newStudent, callback) {
    Student.create(newStudent)
      .then(student => {
        console.log('Added student:', student);
        callback(null, student);
      })
      .catch(error => {
        console.log('Error adding student:', error);
        callback(error, null);
      });
  }
  
  function updateStudent(rollNumber, updatedData, callback) {
    Student.update(updatedData, { where: { rollNumber } })
      .then(([rowsUpdated]) => {
        if (rowsUpdated === 0) {
          callback(null, false); // No student found or no changes made
        } else {
          callback(null, true); // Student updated successfully
        }
      })
      .catch(error => {
        console.log('Error updating student:', error);
        callback(error, null);
      });
  }
  
  function deleteStudent(rollNumber, callback) {
    Student.destroy({ where: { rollNumber } })
      .then(rowsDeleted => {
        if (rowsDeleted === 0) {
          callback(null, false); // No student found or no deletion made
        } else {
          callback(null, true); // Student deleted successfully
        }
      })
      .catch(error => {
        console.log('Error deleting student:', error);
        callback(error, null);
      });
  }
  
  module.exports = {
    getAllStudents,
    getStudentByRollNumber,
    addStudent,
    updateStudent,
    deleteStudent,
  };